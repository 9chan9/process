#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "CommonCode.h"
#include "FingerVeinAlgMacros.h"



unsigned char tempBuff[IMG_MAX_WIDTH*IMG_MAX_HEIGHT];



void pixelCount(const unsigned char * srcImg, int width, int height, int*fpixelNum, int *bpixelNum)
{
	int i;
	int count1 = 0,count2 = 0;	
	*fpixelNum = 0;
	*bpixelNum = 0;
	for(i=0;i<height*width;i++)
	{		
		if(srcImg[i]==FRONT_GROUND_VALUE)
			count1++;
		else if(srcImg[i] ==BACK_GROUND_VALUE)
			count2++;
	}
	*fpixelNum = count1;
	*bpixelNum = count2;
}

//�ֽڱ�ʾ������ת�ɰ�λ��ʾ������
void charToBit(const unsigned char *inputData, unsigned char *outputData,int imgSize)
{
	int index =0;
	unsigned char val =0;
	int i,j;
	for( i=0;i<imgSize/8;i++)
	{	
		val = 0;
		for(j=0;j<8;j++)
		{			
			if(0==inputData[index*8+j])
			{
				val = (val<<1);	
			}else
			{
				val = (val<<1)+1;
			}
		}
		outputData[index]= val;
		index++;
	}
}
//��λ��ʾ������ת���ֽڱ�ʾ������
void bitToChar(const unsigned char *inputData, unsigned char *outputData,int imgSize)
{
	int index =0;
	unsigned char inValue =0;
	unsigned char temValue =0;
	int i,j;
	for( i=0;i<imgSize/8;i++)
	{	
		inValue = inputData[i];		
		temValue = 128;
		for(j=0;j<8;j++)
		{	
			if(0==inValue/temValue)
			{
				outputData[index]= 0;
			}else
			{
				outputData[index]= 255;
				inValue-=temValue;
			}			
			temValue=(temValue>>1);
			index++;
		}		
	}
}


void imgBinary(unsigned char *srcImg,int imgW,int imgH,int threshold)
{
	int i;
	int index =0;
	for(i=0;i<imgH*imgW;i++)
	{
		srcImg[index] = srcImg[index]>threshold ? 255:0;
		index++;
	}	

}
//˫���Բ�ֵ
double getInterpolatedPixel(double x,double y,const unsigned char *srcImg,int imgW,int imgH)
{
	int xBase = (int)x;
	int yBase = (int)y;
	double xFraction = x-xBase;
	double yFraction = y-yBase;

	int offset = yBase*imgW + xBase;
	if(offset+imgW+1>imgW*imgH)
		return 0.0;
	int lowerLeft = srcImg[offset];
	int lowerRight = srcImg[offset+1];
	int upperRight = srcImg[offset+imgW+1];
	int upperLeft = srcImg[offset+imgW];

	double upperAverage = upperLeft+xFraction*(upperRight-upperLeft);
	double lowerAverage = lowerLeft+xFraction*(lowerRight-lowerLeft);
	return lowerAverage + yFraction*(upperAverage-lowerAverage);

}


void imageRotate(const unsigned char *orgImg,unsigned char *rotateImg,int width,int height,float angle)
{
	int x,y;

	double centerX = width/2.0;
	double centerY = height/2.0;
	double angleRadians = angle/(180.0/PI);
	double cosa = cos(angleRadians);
	double sina = sin(angleRadians);

	double tmp1 = centerY*sina -centerX*cosa;
	double tmp2 = -centerX*sina - centerY*cosa;
	double tmp3, tmp4, xs, ys;

	int index;

	double dVal =0.0;
	unsigned char cVal = 0;
	for(y=0;y<height;y++)
	{
		index = y*width;
		tmp3 = tmp1-y*sina+centerX;
		tmp4 = tmp2+y*cosa+centerY;
		for(x=0;x<width;x++)
		{
			xs = x*cosa + tmp3;
			ys = x*sina + tmp4;
			if( (xs>=-0.01)&&(xs<width)&&(ys>=-0.01)&&(ys<height))
			{
				dVal = getInterpolatedPixel(xs,ys,orgImg,width,height)+0.5;
				dVal = dVal<0.0? 0:dVal;
				dVal = dVal>255.0?255:dVal;
				cVal = (unsigned char)dVal;
				rotateImg[index++] = cVal;
			}
			else
			{
				rotateImg[index++]= 0;
			}
		}
	}
}

void imageResize(unsigned char *srcImg,unsigned char *dstImg,int srcW,int srcH,int dstW,int dstH)
{
	int x,y;
	
	double srcCenterX = srcW/2.0;//��ʼͼ������
	double srcCenterY = srcH/2.0;
	double dstCenterX = dstW/2.0;//���ۣ�����  �ߴ�仯������
	double dstCenterY = dstH/2.0;

	double xScale = (double)1.0*dstW/srcW;//��������� 
	double yScale = (double)1.0*dstH/srcH;

	double xs,ys;

	double xlimit = srcW-1.0,xlimit2 = srcW-1.001;//��Ե����
	double ylimit = srcH-1.0,ylimit2 = srcH-1.001;
	int index;
	double dVal =0.0;
	unsigned char cVal = 0;

	if(0==srcW||0==dstW||0==srcH||0==dstH)
		return;
	if(srcW==dstW&&srcH==dstH)
	{
		dataCopy(srcImg,dstImg,srcW, srcH);//����һ��
		return;
	}
	dstCenterX += xScale/2.0;//���ĵ���΢ƫ��
	dstCenterY += yScale/2.0;

	for(y=0;y<dstH;y++)
	{
		ys = (y-dstCenterY)/yScale+srcCenterY;
		ys = ys<0.0 ? 0.0:ys;
		ys = ys>=ylimit? ylimit2:ys;
		index = y*dstW;
		for(x=0;x<dstW;x++)
		{
			xs = (x-dstCenterX)/xScale+srcCenterX;
			xs = xs<0.0?0.0:xs;
			xs = xs>=xlimit?xlimit2:xs;
			dVal = getInterpolatedPixel(xs,ys,srcImg,srcW,srcH);//+0.5;ͼ�����ź����������ʾ��С��������˫���Բ�ֵ  ȡ��Χ������ȡ��ֵ
			dVal = dVal<0.0? 0:dVal;
			dVal = dVal>255.0?255:dVal;
			cVal = (unsigned char)dVal;
			dstImg[index++]=cVal;
		}
	}
}


void imageResize0(unsigned char *srcImg0, unsigned char *dstImg, int srcW, int srcH, int srcStep, int dstW, int dstH)
{
	int x, y;

	double srcCenterX = srcW / 2.0;
	double srcCenterY = srcH / 2.0;
	double dstCenterX = dstW / 2.0;
	double dstCenterY = dstH / 2.0;

	double xScale = (double)1.0*dstW / srcW;
	double yScale = (double)1.0*dstH / srcH;

	double xs, ys;

	double xlimit = srcW - 1.0, xlimit2 = srcW - 1.001;
	double ylimit = srcH - 1.0, ylimit2 = srcH - 1.001;
	int index;
	double dVal = 0.0;
	unsigned char cVal = 0;

	unsigned char* srcImg = (unsigned char*)malloc(srcW*srcH);

	unsigned char* tmpSrc0 = srcImg0;
	int index0 = 0;
	for (int i = 0; i < srcH; i++)
	{
		for (int j = 0; j < srcW; j++)
		{
			srcImg[index0++] = tmpSrc0[j];
		}
		tmpSrc0 += srcStep;
	}

	if (0 == srcW || 0 == dstW || 0 == srcH || 0 == dstH)
		return;
	if (srcW == dstW&&srcH == dstH)
	{
		dataCopy(srcImg, dstImg, srcW, srcH);
		return;
	}
	dstCenterX += xScale / 2.0;
	dstCenterY += yScale / 2.0;

	double _xScale = ((double)srcW) / dstW;
	double _yScale = ((double)srcH) / dstH;

	for (y = 0; y<dstH; y++)
	{
		ys = (y - dstCenterY) * _yScale + srcCenterY;
		ys = ys<0.0 ? 0.0 : ys;
		ys = ys >= ylimit ? ylimit2 : ys;
		index = y*dstW;
		for (x = 0; x<dstW; x++)
		{
			xs = (x - dstCenterX) * _xScale + srcCenterX;
			xs = xs<0.0 ? 0.0 : xs;
			xs = xs >= xlimit ? xlimit2 : xs;
			dVal = getInterpolatedPixel(xs, ys, srcImg, srcW, srcH);//+0.5;
			dVal = dVal<0.0 ? 0 : dVal;
			dVal = dVal>255.0 ? 255 : dVal;
			cVal = (unsigned char)dVal;
			dstImg[index++] = cVal;
		}
	}

	if (srcImg != NULL)
	{
		free(srcImg);
		srcImg = NULL;
	}
}
/******************************************
  ��������
      leftShift/rightShift/upShift/downShitf
  �������ܣ�
      ����/��/��/��ƽ��step������
  ����ο���
      srcImg - �����8U���͵ľ���,
	  dstImg - ��ȡ��8U���͵Ķ�ֵ����
  �����
       ��
  ʱ�䣺
       2015-7-20
*******************************************/
void leftShift(unsigned char * srcImg,unsigned char * dstImg,int width, int height, int step)
{	
	int i,j;
	int index = 0;
	if(srcImg==NULL||width<=0||height<=0)
		return;
	initBuff_UCHAR(dstImg, width, height,0);

	for(i=0;i<height;i++)
	{
		index = i*width;
		for(j=0;j<width-step;j++)
		{
			dstImg[index] = srcImg[index+step];
			index++;
		}		
	}
}
void rightShift(unsigned char * srcImg,unsigned char * dstImg,int width, int height, int step)
{
	int i,j;
	int index = 0;
	if(srcImg==NULL||width<=0||height<=0)
		return;
	initBuff_UCHAR(dstImg, width, height,0);

	for(i=0;i<height;i++)
	{
		index = i*width;
		for(j=width-1;j>step-1;j--)
		{
			dstImg[index+j] = srcImg[index+j-step];
		}
	}
}
void upShift(unsigned char * srcImg,unsigned char * dstImg,int width, int height, int step)
{
	int i,j;
	int index = 0;
	if(srcImg==NULL||width<=0||height<=0)
		return;
	initBuff_UCHAR(dstImg, width, height,0);

	for(j=0;j<width;j++)
	{		
		for(i=0;i<height-step;i++)
		{	
			index = i*width+j;
			dstImg[index] = srcImg[index+step*width];
		}
	}
}

void downShitf(unsigned char * srcImg,unsigned char * dstImg,int width, int height, int step)
{	
	int i,j;
	int index = 0;
	if(srcImg==NULL||width<=0||height<=0)
		return;
	initBuff_UCHAR(dstImg, width, height,0);

	for(j=0;j<width;j++)
	{
		for(i=height-1;i>step-1;i--)
		{
			index = i*width+j;
			dstImg[index] = srcImg[index-step*width];
		}
	}
}


/******************************************
  ��������
      imageShift
  �������ܣ�
      ��ȡָ����ͼ�񾭹�ƽ�ơ���ת�Լ�ƽ�������ı�׼ģ��
	  
  ����ο���
      srcImg - �����8U���͵ľ���,
	  dstImg - ƽ�ƺ��8U���͵Ķ�ֵ����
	  xStep -ˮƽ�����ƶ�������������Ϊ����������Ϊ����
	  yStep -��ֱ�����ƶ�������������Ϊ����������Ϊ����
  �����
       ��
  ʱ�䣺
       2015-7-20
*******************************************/

void imageShift(unsigned char * srcImg,unsigned char * dstImg,int width, int height, int xStep,int yStep)
{
	int dirs;
	unsigned char * tmpImg = tempBuff;
	if(xStep==0&&yStep==0)//û��ƽ��	
	{
		dataCopy(srcImg,dstImg, width, height);
		return;
	}	
	if(xStep>0 && yStep==0)      dirs=0;
	else if(xStep>0 && yStep>0 ) dirs=1;
	else if(xStep==0 && yStep>0) dirs=2;
	else if(xStep<0 && yStep>0 ) dirs=3;
	else if(xStep<0 && yStep==0) dirs=4;
	else if(xStep<0 && yStep<0 ) dirs=5;
	else if(xStep==0 && yStep<0) dirs=6;
	else if(xStep>0 && yStep<0 ) dirs=7;
	
	switch(dirs)
	{
		case 0:
			leftShift(srcImg,dstImg,width, height,xStep);
			break;
		case 1:
			
			leftShift(srcImg,tmpImg,width, height, xStep);
			upShift(tmpImg,dstImg,width, height, yStep);
			break;
		case 2:
			upShift(srcImg,dstImg,width, height, yStep);
			break;
		case 3:
			rightShift(srcImg,tmpImg,width, height, abs(xStep));
			upShift(tmpImg,dstImg,width, height, yStep);
			break;
		case 4:
			rightShift(srcImg,dstImg,width, height, abs(xStep));
			break;
		case 5:
			rightShift(srcImg,tmpImg,width, height, abs(xStep));
			downShitf(tmpImg,dstImg,width, height, abs(yStep));
			break;
		case 6:
			downShitf(srcImg,dstImg,width, height, abs(yStep));
			break;
		case 7:
			leftShift(srcImg,tmpImg,width, height, xStep);
			downShitf(tmpImg,dstImg,width, height, abs(yStep));
			break;
		default:
			break;		
	}
}


void initBuff_UCHAR(unsigned char *orgBuff,int width, int height,unsigned char val)
{
	int i;
	unsigned char *pBuff = orgBuff;

	for(i=0;i<height*width;i++)
	{		
		*(pBuff++)= val;		
	}	

}

void initBuff_FLOAT(float *orgBuff,int width, int height,float val)
{
	int i;
	float *pBuff = orgBuff;

	for(i=0;i<height*width;i++)
	{		
		*(pBuff++)= val;		
	}	
}

void initBuff_INT(int *orgBuff,int width, int height,int val)
{
	int i;
	int *pBuff = orgBuff;

	for(i=0;i<height*width;i++)
	{		
		*(pBuff++)= val;		
	}
		
}

void dataCopy(const unsigned char * inputData,unsigned char *outputData,int width, int height)
{
	int i;
	unsigned char *pBuff = outputData;
	for(i=0;i<height*width;i++)
	{		
		*(pBuff++)= *(inputData++);		
	}
}


void getBlock(const unsigned char *srcImg,unsigned char *dstImg,int imgWidth,int startX,int startY,int buffWidth,int buffHeight)
{
	int i,j;
	unsigned char *pDstImg = dstImg;
	int index =0;
	for(i=startY;i<startY+buffHeight;i++)
	{
		index = i*imgWidth+startX;
		for(j=startX;j<startX+buffWidth;j++)
		{
			*(pDstImg++) = srcImg[index];
			index++;
		}
	}
}

/************************************************************************
FunName: getBorderImg
Funtion: ͼ����չ�߽磬��չֵΪ0
Parspecification:
--input
srcImg---����Դͼ��CV_8U����CV_32F
srcW --ԭͼ��Ŀ�
srcH---ԭͼ�ĳ�
borderImg---��չ���ͼ��
borderW--��չ�߽�Ŀ���
--ouput
	NULl
DatoDevelopment:
2015/07/22
*************************************************************************/

void getBorderImg_UCHAR(unsigned char * srcImg, unsigned char * borderImg, int srcW,int srcH, int borderW)
{
	int i,j;
	int index =0;
	if(borderW<=0)
		return;		
	for(i=0;i<srcH+2*borderW;i++)
	{
		index = i*(srcW+2*borderW);
		for(j=0;j<srcW+2*borderW;j++)
		{
			if(i<borderW||i>=srcH+borderW||j<borderW||j>=srcW+borderW)
			{
				borderImg[index] = 0;
			}
			else
			{
				borderImg[index] = srcImg[(i-borderW)*srcW+j-borderW];
			}
			index++;
		}
	}		
}

void getBorderImg_FLOAT(float * srcImg, float * borderImg, int srcW,int srcH, int borderW)
{
	int i,j;
	int index =0;
	if(borderW<=0)
		return;		
	for(i=0;i<srcH+2*borderW;i++)
	{
		index = i*(srcW+2*borderW);

		for(j=0;j<srcW+2*borderW;j++)
		{
			if(i<borderW||i>=srcH+borderW||j<borderW||j>=srcW+borderW)
			{
				borderImg[index] = 0.0;
			}
			else
			{
				borderImg[index] = srcImg[(i-borderW)*srcW+j-borderW];
			}
			index++;
		}
	}		
}

void getBorderImg_UCHAR2FLOAT(unsigned char * srcImg, float * borderImg, int srcW,int srcH, int borderW)
{
	int i,j;
	int index =0;
	if(borderW<=0)
		return;		
	for(i=0;i<srcH+2*borderW;i++)
	{
		index = i*(srcW+2*borderW);
		for(j=0;j<srcW+2*borderW;j++)
		{
			if(i<borderW||i>=srcH+borderW||j<borderW||j>=srcW+borderW)
			{
				borderImg[index] = 0.0;
			}
			else
			{
				borderImg[index] = (float)srcImg[(i-borderW)*srcW+j-borderW];
			}
			index++;
		}
	}		
}

//��ʴ����
void erosion(unsigned char *image,int width,int height,int r )
{
	int i,j,m,n;
	int flag;
	unsigned char * pBuff = tempBuff;

	dataCopy(image,pBuff,width,height);

	for( i=r;i<height-r;i++)
	{
		for(j=r;j<width-r;j++)
		{
			flag =1;
			for(m=i-r;m<=i+r;m++)
			{
				for(n=j-r;n<=j+r;n++)
				{
					if(!pBuff[i*width+j]||!pBuff[m*width+n])
					{
						flag = 0;
						break;
					}
				}
			}
			if(flag==0)
			{
				image[i*width+j] = 0;
			}
			else
			{
				image[i*width+j] = 255;
			}
		}
	}
}

//��������
//width:ͼ�����height��ͼ��ߣ�������Ĥ�ı߳���2*r+1)
void diate(unsigned char *image,int width,int height,int r )
{
	int i,j,m,n;
	int flag;
	unsigned char * pBuff = tempBuff;
	
	dataCopy(image,pBuff,width,height);
	for( i=r;i<height-r;i++)
	{
		for(j=r;j<width-r;j++)
		{
			flag =1;
			for(m=i-r;m<=i+r;m++)
			{
				for(n=j-r;n<=j+r;n++)
				{
					if(255==pBuff[i*width+j]||255==pBuff[m*width+n])
					{
						flag = 0;
						break;
					}
				}
			}
			if(flag==0)
			{
				image[i*width+j] = 255;
			}
			else
			{
				image[i*width+j] = 0;
			}
		}
	}
}

void morphologyEx(unsigned char *image,int width,int height,int type)
{	
	if(type==1)//������
	{
		//����
		diate(image, width, height ,1);
		//��ʴ
		erosion(image, width, height,1 );
	}
	else if(type==2)//������
	{
		//��ʴ
		erosion(image, width, height,1 );
		//����
		diate(image, width, height,1 );		
	}
}

//����˷�����ӦԪ�����
void matMultiply(float *srcImg1,float *srcImg2,float *dstImg,int width,int height)
{
	int i;
	int index=0;

	for(i=0;i<height*width;i++)
	{					
		dstImg[index]= srcImg1[index]*srcImg2[index];
		index++;
	}

}
//�������� dstImg =k*srcImg1+srcIgm2
void matMultAdd(float *srcImg1,float k,float *srcImg2,float *dstImg,int width,int height)
{
	int i;
	int index=0;
	for(i=0;i<height*width;i++)
	{					
		dstImg[index]= srcImg1[index]*k+srcImg2[index];
		index++;
	}

	
}

//������Գ���
void matDivide(float *srcImg,float k,float *dstImg,int width,int height)
{	
	int i;
	int index=0;
	for(i=0;i<height*width;i++)
	{					
		dstImg[index]= srcImg[index]/k;
		index++;
	}
	
}

//����Ԫ������
void matNot(float *image,int width, int height)
{
	int i;
	int index=0;
	for(i=0;i<height*width;i++)
	{					
		image[index] = image[index]*(-1);	
		index++;
	}
}
//
void matExp(float *image,int width, int height)
{
	int i;
	int index=0;
	for(i=0;i<height*width;i++)
	{					
		image[index] = exp(image[index]);	
		index++;
	}
	
}

//�����������ӦԪ�����
void matSubtract(unsigned char *srcImg1,unsigned char *srcImg2,int *dstImg,int width,int height)
{
	int i;
	int index=0;
	for(i=0;i<height*width;i++)
	{					
		dstImg[index]= srcImg1[index]-srcImg2[index];	
		index++;
	}
}
/************************************************************************
FunName: meanFilter
Funtion: ��ֵ�˲���ͼ��ƽ��
Parspecification:
--input
srcImg---����Դͼ��
dstImg---ƽ�����ͼ��
--ouput
	NULl
DatoDevelopment:
2015/07/22
*************************************************************************/
void meanFilter(unsigned char * srcImg,unsigned char * dstImg,int imgW,int imgH,int blockSize)
{
	int i,j,m,n;
	int sum = 0;
	int val = 0;
	int num = (blockSize*2+1)*(blockSize*2+1);
	int bW =(imgW+2*blockSize);
	int index =0;
	unsigned char *borderImg = new unsigned char[IMG_MAX_WIDTH*IMG_MAX_HEIGHT];
	memset(borderImg, 0, IMG_MAX_WIDTH*IMG_MAX_HEIGHT);

	getBorderImg_UCHAR(srcImg,borderImg,imgW,imgH,blockSize);

	for ( i = blockSize; i < imgH+blockSize; i++)
	{
		index = i*bW + blockSize;

		for ( j = blockSize; j < imgW+blockSize; j++)
		{			
			sum = 0;
			for ( m = -blockSize; m <=blockSize; m++)
			{
				for ( n = -blockSize; n <= blockSize; n++)
				{	
					sum += borderImg[index + m*bW + n];
				}
			}
			index++;
			val = (int) (sum / num);
			dstImg[(i-blockSize)*imgW+ j-blockSize] = val;
		}
	}
	delete [] borderImg;
}

//�����Сֵ
void getMaxMin_INT(int *srcImg,int imgW,int imgH,int *pMax,int *pMin)
{
	int i,j;
	int value = 0;
	int max = INT_MIN;
	int min = INT_MAX;
	int index = 0;

	for(i=0;i<imgH;i++)
	{
		index =i*imgW;
		for(j=0;j<imgW;j++)
		{
			value = srcImg[index];
			index++;
			max  = value>max? value:max;
			min  = value<min? value:min;
		}
	}
	*pMax = max;
	*pMin = min;	
}

//�����Сֵ
void getMaxMin_UCHAR(unsigned char * srcImg,int imgW,int imgH,unsigned char *pMax,unsigned char *pMin)
{
	int i,j;
	int value = 0;
	unsigned char  max = 0;
	unsigned char  min = 255;
	int index =0;

	for(i=0;i<imgH;i++)
	{
		index =i*imgW;
		for(j=0;j<imgW;j++)
		{
			value = srcImg[index];
			index++;
			max  = value>max? value:max;
			min  = value<min? value:min;
		}
	}
	*pMax = max;
	*pMin = min;
	
}
//��䷽�������ֵ
void oustThreshold(int *srcImg,int imgW,int imgH,int *Thresholdbest)
{
	int grayMax = -255;
	int grayMin = 255;	
	int i,j;
	int  a;
	float b;	
	float pTemp1[512] = {0};	
	float W0 = 0;
	int threshold = 0;
	float JFC = 0;
	float JFCMAX = 0;
	float P1=0;//������
	float W1=0;//����������
	float W1Sum = 0;
	float P2=0;//ǰ����
	float W2=0;//ǰ��������
	float W2Sum = 0;

	int InputSize=imgH*imgW;
	*Thresholdbest = 0;
	getMaxMin_INT(srcImg, imgW, imgH,&grayMax,&grayMin);

	threshold = 1;

	//ͳ�Ƹ��Ҷ�ֵ�ĸ���
    for(i=0; i<imgH; i++)
	{
		for (j=0; j<imgW; j++)
		{ 	 			  
			a = srcImg[i*imgW+j];
			pTemp1[a-grayMin]++;			
		}
	}

	for(i=0; i<=grayMax-grayMin; i++)
	{		
		pTemp1[i] /= InputSize;
		W0 += i*pTemp1[i];
		P2 += pTemp1[i];
	}
	
	W2Sum = W0;	
	
	while(threshold>0 && threshold<grayMax-grayMin)
	{
        b = pTemp1[threshold];

		P1 += b;
        W1Sum += threshold*b;			
		if(P1>0)
		{
			W1 = W1Sum/P1;//������ҶȾ�ֵ
		}
		
	    P2 -= b;
        W2Sum -= threshold*b;		
		if(P2>0 && W2Sum>=0)
		{
			W2 = W2Sum/P2;//ǰ����ҶȾ�ֵ
		}	
 
		JFC=P1*P2*(W2-W1)*(W2-W1);
       
		if(JFC > JFCMAX)
		{
			JFCMAX = JFC;
			*Thresholdbest = threshold+grayMin;
		}		
        threshold ++; 
	}	
}

float variance(unsigned char *buff,int length)
{
	int i = 0;
	int sum = 0;
	float average = 0.0;
	float var = 0.0;
	if(length<=0)
		return var;
	for(i=0;i<length;i++)
	{
		sum+=buff[i];
	}
	average = sum/length;
	sum=0;
	for(i=0;i<length;i++)
	{
		sum+=(buff[i]-average)*(buff[i]-average);
	}
	var = (1.0*sum)/length;
	return var;
}

float variance_INT(int *buff,int length)
{
	int i = 0;
	int sum = 0;
	float average = 0.0;
	float var = 0.0;
	if(length<=0)
		return var;
	for(i=0;i<length;i++)
	{
		sum+=buff[i];
	}
	average = sum/length;
	sum=0;
	for(i=0;i<length;i++)
	{
		sum+=(buff[i]-average)*(buff[i]-average);
	}
	var = (1.0*sum)/length;
	return var;
}
/************************************************************************
FunName: getCycleTransform
Funtion: ������ת�������
Parspecification:
--input
tmpArray---����
len---���鳤��
--ouput
--��ת�������
DatoDevelopment:
2015/07/22

*************************************************************************/
int getCycleTransform(unsigned char tmpArray[],int len)
{
	int i;
	int sumTrans=0;
	for( i=0;i<len;i++)
	{
		sumTrans +=tmpArray[i]==tmpArray[(i+1)%8]? 0:1;
	}
	return sumTrans;
}



void encryptKeyInit(unsigned char *DeEncriptKey,float x0, int u0,int length)
{
	if(length<=0||DeEncriptKey==NULL)
		return;
	unsigned int *imageDeEncriptArray = new unsigned int[length];

	imageDeEncriptArray[0] = (unsigned int)(x0*1024);//256;//0.25��1024
	for(int i=1;i<length;i++)
	{
		imageDeEncriptArray[i]=u0*imageDeEncriptArray[i-1]*(1024-imageDeEncriptArray[i-1])>>10;
	}

	for(int i=0;i<length;i++)
	{
		DeEncriptKey[i]=(unsigned char)(imageDeEncriptArray[i]%256);
	}

	delete[] imageDeEncriptArray;
}

void imgDecrypt(unsigned char *inputData,unsigned char *outputData,unsigned char *DeEncriptKey,int length)
{
	if(length<=0||DeEncriptKey==NULL||inputData==NULL)
		return;
	for(int i=0; i<length; i++)
	{
		outputData[i] =inputData[i]^DeEncriptKey[i];		
	}
}

void imgDecrypt(unsigned char *imageData,unsigned char *DeEncriptKey,int length)
{
	if(!imageData)
		return;
	for(int i=0; i<length; i++)
	{
		imageData[i*2] ^=DeEncriptKey[i];
		imageData[i*2 + 1] ^=DeEncriptKey[i];
		imageData[i*2 + 1] &=0x03;
	}
}




void dataEnDecrypt(unsigned char *srcData,unsigned char *dstData,int imgSize)
{
	float x0 =DECRYT_X0;//0.25
	int u0 = DECRYT_U0;//3

	unsigned char *pKey = new unsigned char[imgSize];


	encryptKeyInit(pKey,x0,u0,imgSize);

	imgDecrypt(srcData,dstData,pKey,imgSize);
	delete[] pKey;
}

const char * base64char = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

int  base64Encode( const unsigned char * bindata, char * base64, int binlength )
{
	int i, j;
	unsigned char current;

	for ( i = 0, j = 0 ; i < binlength ; i += 3 )
	{
		current = (bindata[i] >> 2) ;
		current &= (unsigned char)0x3F;
		base64[j++] = base64char[(int)current];

		current = ( (unsigned char)(bindata[i] << 4 ) ) & ( (unsigned char)0x30 ) ;
		if ( i + 1 >= binlength )
		{
			base64[j++] = base64char[(int)current];
			base64[j++] = '=';
			base64[j++] = '=';
			break;
		}
		current |= ( (unsigned char)(bindata[i+1] >> 4) ) & ( (unsigned char) 0x0F );
		base64[j++] = base64char[(int)current];

		current = ( (unsigned char)(bindata[i+1] << 2) ) & ( (unsigned char)0x3C ) ;
		if ( i + 2 >= binlength )
		{
			base64[j++] = base64char[(int)current];
			base64[j++] = '=';
			break;
		}
		current |= ( (unsigned char)(bindata[i+2] >> 6) ) & ( (unsigned char) 0x03 );
		base64[j++] = base64char[(int)current];

		current = ( (unsigned char)bindata[i+2] ) & ( (unsigned char)0x3F ) ;
		base64[j++] = base64char[(int)current];
	}
	base64[j] = '\0';
	return j;
}

int base64Decode( const char * base64, unsigned char * bindata )
{
	int i, j;
	unsigned char k;
	unsigned char temp[4];
	for ( i = 0, j = 0; base64[i] != '\0' ; i += 4 )
	{		 
		temp[0] = 0;
		temp[1] = 0;
		temp[2] = 0;
		temp[3] = 0;
		for ( k = 0 ; k < 64 ; k ++ )
		{
			if ( base64char[k] == base64[i] )
				temp[0]= k;
		}
		for ( k = 0 ; k < 64 ; k ++ )
		{
			if ( base64char[k] == base64[i+1] )
				temp[1]= k;
		}
		for ( k = 0 ; k < 64 ; k ++ )
		{
			if ( base64char[k] == base64[i+2] )
				temp[2]= k;
		}
		for ( k = 0 ; k < 64 ; k ++ )
		{
			if ( base64char[k] == base64[i+3] )
				temp[3]= k;
		}
		/*if( 64==temp[0] ||64==temp[1] ||64==temp[2] ||64==temp[3] )
		{
			return -1;
		}*/

		bindata[j++] = ((unsigned char)(((unsigned char)(temp[0] << 2))&0xFC)) |
			((unsigned char)((unsigned char)(temp[1]>>4)&0x03));
		if ( base64[i+2] == '=' )
			break;

		bindata[j++] = ((unsigned char)(((unsigned char)(temp[1] << 4))&0xF0)) |
			((unsigned char)((unsigned char)(temp[2]>>2)&0x0F));
		if ( base64[i+3] == '=' )
			break;

		bindata[j++] = ((unsigned char)(((unsigned char)(temp[2] << 6))&0xF0)) |
			((unsigned char)(temp[3]&0x3F));
	}
	return j;
}

//char Base64[MAX_BUFF_SIZE]={0};
void  base64EncodeUCHAR( const unsigned char * inputData, char * outputData, int inputLen,int *outPutLen )
{

	char *Base64 = new char [MAX_BUFF_SIZE];
	memset(Base64,0,MAX_BUFF_SIZE);
	int len1 = base64Encode( inputData,  Base64,  inputLen );
	
	for( int i=0;i<len1;i++)
	{
		outputData[i]= Base64[i];
	}
	*outPutLen = len1;
	delete[]Base64;
}

//void base64DecodeUCHAR( const unsigned char * inutData, unsigned char * outputData, int inputLen,int *outPutLen )
//{
//	char *Base64 = new char [MAX_BUFF_SIZE];
//	memset(Base64,0,MAX_BUFF_SIZE);
//	for( int i=0;i<inputLen;i++)
//	{
//		Base64[i]= inutData[i];
//	}
//	 *outPutLen = base64Decode( Base64, outputData );
//	delete []Base64;
//
//}

int  base64DecodeUCHAR( const unsigned char * inutData, unsigned char * outputData, int inputLen,int *outPutLen )
{
	char *Base64 = new char [MAX_BUFF_SIZE];
	memset(Base64,0,MAX_BUFF_SIZE);
	for( int i=0;i<inputLen;i++)
	{		
		unsigned char num = inutData[i];
		if(43==num||(num>=47&&num<=57)||(num>=65&&num<=90)||(num>=97&&num<=122))
		{
			Base64[i]= inutData[i];
		}
		else
		{
			return -1;
		}
	}
	 *outPutLen = base64Decode( Base64, outputData );
	delete []Base64;
	return 0;
}

int isErrorModel(unsigned char *model, int modelLen)
{
	if(modelLen<=0)
		return -1;
	int sum =0;
	for(int i=0;i<modelLen/2;i++)
	{
		sum+=(model[i]-model[modelLen-(i+1)]);
	}
	if(0==sum)
		return 1;
	else
		return 0;
}
