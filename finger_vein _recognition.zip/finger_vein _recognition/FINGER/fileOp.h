#ifndef __FILEOP_H__
#define __FILEOP_H__
#include <io.h>      
#include <string>    
#include <vector>    
#include <iostream>    
using namespace std;
void getAllFiles(string path, vector<string>& files, string format);
string&   replace_all(string&   str, const   string&   old_value, const   string&   new_value);
string&   replace_all(string&   str, const   string&   old_value, const   string&   new_value);

#endif