#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <algorithm>
#include "CommonCode.h"
#include "ROILocation.h"
#include "FingerVeinAlgMacros.h"
#include <vector>
using namespace std;

unsigned char c_buff_big2[ORI_IMG_ROWS*ORI_IMG_COLS]={0};
unsigned char c_buff_big3[ORI_IMG_ROWS*ORI_IMG_COLS]={0};
unsigned char c_buff_small0[ORI_IMG_ROWS*ORI_IMG_COLS/4]={0};
unsigned char c_buff_small1[ORI_IMG_ROWS*ORI_IMG_COLS/4]={0};
int i_buff_small[ORI_IMG_ROWS*ORI_IMG_COLS/4]={0};

#define  MASK_LEN  9 //ģ�峤��

#define MAX_3(a,b,c) max(max(a,b),max(a,c))

/************************************************************************
FunName: fitLine
Funtion: ��С���˷����ֱ�� y = k*x+b;
Parspecification:
--input
points---�������ϵ�
num---�����Ŀ
linePara---��ϳ�����ֱ�߲�����k,b,
DatoDevelopment:
2015/07/30
Developers:
WangDanDan
*************************************************************************/
void fitLine(const Point points[],const int num ,Line *linePara)
{
	int i;
	float sumX = 0.f;
	float sumY = 0.f;
	float sumXX = 0.f;
	float sumYX = 0.f;
	float d;

	for(i=0;i<num;i++)
	{
		sumX += points[i].x;
		sumY += points[i].y;
		sumXX += points[i].x * points[i].x;
		sumYX += points[i].x * points[i].y;
	}
	sumX /= num;
	sumY /= num;
	sumXX /= num;
	sumYX /= num;	
	d = sumX*sumX-sumXX;

	linePara->b =0.f;
	if(fabs(d)<0.001)
	{
		linePara->b = sumX;
		linePara->flag = -1; //б��Ϊ0��ˮƽ��
		linePara->k=0;
	}
	linePara->k = (sumX*sumY-sumYX)/d;//����ͬ����X�Ļ�������ͨ��ʽ��ͬ  �����������㷨���Ա������
	linePara->b = sumY-sumX*linePara->k;
	linePara->flag =1;
}

/************************************************************************
FunName: sort_y
Funtion: ����y�����һ���������
Parspecification:
--input
points---������������
num---�����Ŀ
DatoDevelopment:
2015/07/30
Developers:
WangDanDan
*************************************************************************/

void sort_y(Point points[], int num)
{
	int i,j;
	Point tmp;
	for(i=0;i<num-1;i++)
	{
		for(j=i+1;j<num;j++)
		{
			if(points[i].y>points[j].y)
			{
				tmp = points[i];
				points[i] = points[j];
				points[j] = tmp;
			}
		}
	}
}

/************************************************************************
FunName: selectPoints_y
Funtion: ����y����ɸѡ��ϵ�
Parspecification:
--input
points---��ϵ�����
num---��ϵ����Ŀ
DatoDevelopment:
2015/07/30
Developers:
WangDanDan
*************************************************************************/

void selectPoints_y( Point points[],int *pointNum)
{
	int num =*pointNum;
	int i,j;	
	Point tmp[50];
	int sum =0;

	int FitPointNum = num<FIT_POINT_NUM? num:FIT_POINT_NUM;	

	for(i=0;i<num;i++)
	{
		tmp[i].x=points[i].x;
		tmp[i].y=points[i].y;
		sum += points[i].y;
	}
	sum/=num;
	for( i=0;i<num-1;i++)
	{
		if(abs(tmp[i].y-sum)>30)//ƫ���м��Զ�ĵ㲻�������
		{
			tmp[i].y = 255;
		}
		else tmp[i].y = abs(tmp[i+1].y-tmp[i].y);

	}
	//��tmp[]����
	sort_y(tmp,num-1);

	for( i=0;i<FitPointNum;i++)
	{
		for( j=0;j<num;j++)
		{
			if(tmp[i].x ==points[j].x)
			{
				tmp[i].y = points[j].y;
				break;
			}
		}
	}
	for(i=0;i<FitPointNum;i++)
	{
		points[i].x = tmp[i].x;
		points[i].y = tmp[i].y;
	}
	*pointNum = FitPointNum;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void CalRotatedPoints(Point * edgePoints, int  pointNum, float angle, Point center)
{
	int i =0;
	float theta = angle*PI/180;
	//float theta = angle;
	float beta = 0.0, alpha = 0.0;
	float radius =0.0;
	int x0 = 0, y0 = 0;
	int x1 = 0, y1 = 0;

	for(i=0;i<pointNum;i++)
	{
		x0 = edgePoints[i].x - center.x;
		y0 = edgePoints[i].y - center.y;
		radius = sqrt((float)(x0*x0 + y0*y0));
		beta = atan2((float)y0,(float)x0);
		alpha = beta-theta;
		x1 = radius * cos(alpha);
		y1 = radius * sin(alpha);
		edgePoints[i].x = x1 + center.x;
		edgePoints[i].y = y1 + center.y;
	}

}

void DetectFingerEdge(int *upEdgePoints,int *lowEdgePoints,int imgWidth,int imgHeight,float angle, int *uperEdgeRow,int *lowerEdgeRow)
{
	Point upPoints[MAX_SELECT_POINT_NUM];
	Point lowPoints[MAX_SELECT_POINT_NUM];
	int xStart = X_START;
	int xEnd = X_END;
	int step =JUMP_STEP;
	int countUpPoints = 0,countLowPoints = 0;
	Point center;
	int upMax = UP_Y_START;
	int lowMin = LOW_Y_END;
	int sumY = 0;
	int tmpY = 0;

	*uperEdgeRow = UP_Y_START;
	*lowerEdgeRow = LOW_Y_END;

	for(int i=0;i<MAX_SELECT_POINT_NUM;i++)
	{
		if(upEdgePoints[i]>UP_Y_START&&upEdgePoints[i]<UP_Y_END)
		{
			upPoints[countUpPoints].x = i*step + xStart;
			upPoints[countUpPoints].y = upEdgePoints[i];
			countUpPoints++;
		}
	}

	for(int i=0;i<MAX_SELECT_POINT_NUM;i++)
	{
		if(lowEdgePoints[i]>LOW_Y_START&&lowEdgePoints[i]<LOW_Y_END)
		{
			lowPoints[countLowPoints].x = i*step + xStart;
			lowPoints[countLowPoints].y = lowEdgePoints[i];
			countLowPoints++;
		}
	}

	if(0==countUpPoints||0==countLowPoints)
		return;

	center.x =imgWidth/2;
	center.y = imgHeight/2;

	CalRotatedPoints(upPoints, countUpPoints, angle, center);
	CalRotatedPoints(lowPoints, countLowPoints, angle, center);

	sumY = 0;
	for(int i=0;i<countUpPoints;i++)
	{
		tmpY =upPoints[i].y;
		sumY += tmpY;	
		if(tmpY>upMax)
		{
			upMax =tmpY;
		}
	}
	sumY /= countUpPoints;//��ֵ
	if((upMax-sumY)>15) //��ֵ�����ֵ�Ƚ�����Ƿ�ϴ�
	{
		*uperEdgeRow =sumY+3;
	}
	else
	{
		*uperEdgeRow =upMax;
	}

	sumY = 0;
	for(int i=0;i<countLowPoints;i++)
	{
		tmpY =lowPoints[i].y;
		sumY += tmpY;	
		if(tmpY<lowMin)
		{
			lowMin = tmpY;
		}
	}
	sumY /= countLowPoints;

	if((sumY - lowMin)>15)
	{
		*lowerEdgeRow =sumY-3;
	}
	else
	{
		*lowerEdgeRow =lowMin;
	}

}


int  upLocGrad( unsigned char* srcImg,int imgWidth,int imgHeight,int locX, int locY)
{
	unsigned char *p_srcImg1,*p_srcImg2;
	p_srcImg1 = (unsigned char *)(srcImg+(locY+1)*imgWidth+locX-MASK_LEN/2);
	p_srcImg2 = (unsigned char *)(srcImg+(locY-1)*imgWidth+locX-MASK_LEN/2);
	int sum = 0;
	for(int n=0;n<MASK_LEN;n++)
	{
		sum+= *(p_srcImg1++)- *(p_srcImg2++);
	}
	return sum;
}
int  lowLocGrad( unsigned char* srcImg,int imgWidth,int imgHeight,int locX, int locY)
{
	unsigned char *p_srcImg1,*p_srcImg2;
	p_srcImg1 = (unsigned char *)(srcImg+(locY-1)*imgWidth+locX-MASK_LEN/2);
	p_srcImg2 = (unsigned char *)(srcImg+(locY+1)*imgWidth+locX-MASK_LEN/2);
	int sum = 0;
	for(int n=0;n<MASK_LEN;n++)
	{
		sum+= *(p_srcImg1++)- *(p_srcImg2++);//���м��ֵ��
	}
	return sum;
}
//��Ե�㲻�㣬ʹ�þֲ�����ݶ�ֵ�ض�λ
int RelocateEdge(unsigned char *srcImg,int *uperEdge, int *lowEdge,int imgWidth,int imgHeight)
{
	int upEdgePointNum = 0;
	int lowEdgePointNum = 0;
	for(int i=0;i<MAX_SELECT_POINT_NUM;i++)
	{
		if(0!=uperEdge[i])
			upEdgePointNum++;
		if(0!=lowEdge[i])
			lowEdgePointNum++;
	}
//�ϱ�Ե�㲻��
	if(upEdgePointNum<1)
	{
		return -1;
	}
	if(upEdgePointNum<25)
	{
		for(int i=1;i<MAX_SELECT_POINT_NUM-1;i++)
		{
			if(0!=uperEdge[i-1]&&0==uperEdge[i])
			{
				int maxGrad = 0;//����ݶ�ֵ
				int curRow = 0;
				for(int j=uperEdge[i-1]+10;j>=uperEdge[i-1]-10; j--)
				{
					//JUMP_STEP
					//�Ҷ�ͼ�����¼���ֲ��ݶ�
					int locX = X_START+i*JUMP_STEP;
					int locY = j;
					int grad1 = upLocGrad( srcImg, imgWidth, imgHeight, locX, locY);
					int grad2 = upLocGrad( srcImg, imgWidth, imgHeight, locX-5, locY);
					int grad3 = upLocGrad( srcImg, imgWidth, imgHeight, locX+5, locY);
					if(grad1>200&&grad2>200&&grad3>200)
					{
						curRow = j;
						break;
					}
					else if(grad1>maxGrad)
					{
						maxGrad = grad1;
						curRow = j;
					}
				}
				uperEdge[i] = curRow;
			}							
		}
	}

//�±�Ե�㲻��
	if(lowEdgePointNum<1)
	{
		return -1;
	}
	if(lowEdgePointNum<25)
	{
		for(int i=1;i<MAX_SELECT_POINT_NUM-1;i++)
		{
			if(0!=lowEdge[i-1]&&0==lowEdge[i])
			{
				int maxGrad = 0;//����ݶ�ֵ
				int curRow = 0;
				for(int j=lowEdge[i-1]-10;j<=lowEdge[i-1]+10; j++)
				{
					//JUMP_STEP
					//�Ҷ�ͼ�����¼���ֲ��ݶ�
					int locX = X_START+i*JUMP_STEP;
					int locY = j;
					int grad1 = lowLocGrad( srcImg, imgWidth, imgHeight, locX, locY);
					int grad2 = lowLocGrad( srcImg, imgWidth, imgHeight, locX-5, locY);
					int grad3 = lowLocGrad( srcImg, imgWidth, imgHeight, locX+5, locY);
					if(grad1>200&&grad2>200&&grad3>200)
					{
						curRow = j;
						break;
					}
					else if(grad1>maxGrad)
					{
						maxGrad = grad1;
						curRow = j;
					}
				}
				lowEdge[i] = curRow;
			}							
		}
	}

	return 0;
	
}


int  findMiddleLine(int *uperEdge, int *lowerEdge,int imgWidth,int imgHeight,Line *midLine)
{
	int j;
	Point middlePoint[MAX_SELECT_POINT_NUM];//= {Point(0,0)};
	int XStart = X_START;
	int XEnd = X_END;
	

	int pointNum=0;
	int k = 0;
	for(j=XStart;j<XEnd;j+=JUMP_STEP)
	{				
		//�������±�Ե������м��
		if(uperEdge[k]<UP_Y_START||uperEdge[k]>UP_Y_END||lowerEdge[k]>LOW_Y_END||lowerEdge[k]==0)
		{
			k++;
			continue;
		}
		middlePoint[pointNum].x = j;		
		middlePoint[pointNum].y =  (uperEdge[k]+lowerEdge[k])/2;	
		k++;
		pointNum++;
	}
	//ɸѡ�м��
	if(pointNum < MIN_FIT_POINT_NUM)
	{
		return -1;
	}
	selectPoints_y(middlePoint,&pointNum);	//����y��������ٴ� ɸѡ
	//���ֱ��	
	fitLine(middlePoint,pointNum,midLine);
	return 0;
	
}

//���ѡȡ��Ե��
void DetectEdgePoints(unsigned char *gradImg,int *upEdgePoints,int *lowEdgePoints,int imgWidth,int imgHeight)
{
	int i,j;
	unsigned char val1 = 0, val2 =0, val3 = 0;
	int XStart = X_START;
	int XEnd = X_END;
	int upYStart = UP_Y_START;
	int upYEnd = UP_Y_END;
	int lowYStart = LOW_Y_START;
	int lowYEnd = LOW_Y_END;	
	int pointNum=0;
	int index = 0;
	unsigned char *p_srcImg;

	for(j=XStart;j<XEnd;j+=JUMP_STEP)//��Ծѡȡ��Ե��
	{		
		//�ϱ�Ե��
		for( i=upYEnd-1;i>=upYStart; i--)
		{		
			index = i*imgWidth+j;
			val1 = gradImg[index];
			/*val2 = gradImg[index-5];
			val3 = gradImg[index+5];*/
			val2 = MAX_3(gradImg[index-5],gradImg[index-2*imgWidth-5],gradImg[index+2*imgWidth-5]);//��Χ��ȡ��ֵ
			val3 = MAX_3(gradImg[index+5],gradImg[index-2*imgWidth+5],gradImg[index+2*imgWidth+5]);
			
			if(val1>200&&val2>200&&val3>200)//����ͼ��Ҷ�ֵ����200��ֵ����     ��ֵѡȡ�������Զ���
			{
				upEdgePoints[pointNum] = i;//��ŵ�y����
				break;
			}
		}
		pointNum++;
	}	

	pointNum=0;
	for(j=XStart;j<XEnd;j+=JUMP_STEP)
	{		
		//�±�Ե��
		for( i=lowYStart;i<lowYEnd; i++)
		{		
			index = i*imgWidth+j;
			val1 = gradImg[index];
			/*val2 = gradImg[index-5];
			val3 = gradImg[index+5];*/
			val2 = MAX_3(gradImg[index-5],gradImg[index-2*imgWidth-5],gradImg[index+2*imgWidth-5]);
			val3 = MAX_3(gradImg[index+5],gradImg[index-2*imgWidth+5],gradImg[index+2*imgWidth+5]);
			if(val1>200&&val2>200&&val3>200)
			{
				lowEdgePoints[pointNum] = i;
				break;
			}
		}
		pointNum++;
	}	
 	return ;
}

void FingerEdgeGrad(const unsigned char *srcImg,unsigned char *gradImg,int imgWidth,int imgHeight)
{	
	int i, j, m, n,k;	
	int sum=0;
	unsigned char val =0;
	int XStart = X_START;
	int XEnd = X_END;
	int upYStart = UP_Y_START;
	int upYEnd = UP_Y_END;
	int lowYStart = LOW_Y_START;
	int lowYEnd = LOW_Y_END;
	int index = 0;
	unsigned char *p_srcImg1,*p_srcImg2;
	int maskLen = MASK_LEN/2;
	int gradVal = 0;
	//��ʼ���ݶ�ͼ
	memset(gradImg,0,imgWidth*imgHeight);

#if 1
////////////////////////////////////////////////////////////////////////////////////////////////////
	int *sumBuff = i_buff_small;
	memset(sumBuff,0,imgWidth*imgHeight);

	for(i=upYStart-1;i<=upYEnd;i++)
	{
		index = i*imgWidth+XStart-maskLen;
		sum=0;	
		for(j=XStart-maskLen;j<XEnd+maskLen;j++)
		{				
			sum +=*(srcImg+index);	
			*(sumBuff+index) = sum;			
			index++;
		}		
	}

	for(i=upYStart;i<upYEnd;i++)
	{
		index = i*imgWidth+XStart;
		for(j=XStart;j<XEnd;j++)
		{
			gradVal = (*(sumBuff+index+imgWidth+ maskLen)- *(sumBuff+index+imgWidth- maskLen))
					-(*(sumBuff+index-imgWidth+ maskLen)- *(sumBuff+index-imgWidth- maskLen));	
			gradVal = gradVal<0?0:gradVal;
			gradVal = gradVal>255?255:gradVal;		
			*(gradImg+index) = (unsigned char)gradVal;		
			index++;
		}		
	}
		

	for(i=lowYStart-1;i<=lowYEnd;i++)
	{
		index = i*imgWidth+XStart-maskLen;
		sum=0;	
		for(j=XStart-maskLen;j<XEnd+maskLen;j++)
		{				
			sum +=*(srcImg+index);	
			*(sumBuff+index) = sum;
			index++;
		}		
	}

	for(i=lowYStart;i<lowYEnd;i++)
	{
		index = i*imgWidth+XStart;
		for(j=XStart;j<XEnd;j++)
		{
			gradVal = (*(sumBuff+index-imgWidth+ maskLen)- *(sumBuff+index-imgWidth- maskLen))
					-(*(sumBuff+index+imgWidth+ maskLen)- *(sumBuff+index+imgWidth- maskLen));	
			gradVal = gradVal<0?0:gradVal;
			gradVal = gradVal>255?255:gradVal;		
			*(gradImg+index) = (unsigned char)gradVal;		
			index++;
		}		
	}

#endif
////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
	//�ϱ�Ե�ݶ�
	for(i=upYStart;i<upYEnd;i++)
	{
		index = i*imgWidth+XStart;
		for(j=XStart;j<XEnd;j++)
		{
			sum=0;			
			p_srcImg1 = (unsigned char *)(srcImg+index+imgWidth-maskLen);
			p_srcImg2 = (unsigned char *)(srcImg+index-imgWidth-maskLen);
			for( n=0;n<MASK_LEN;n++)
			{
				sum+= *(p_srcImg1++)- *(p_srcImg2++);
			}

			sum = sum<0?0:sum;
			sum = sum>255?255:sum;			
			val = (unsigned char)(sum);
			*(gradImg+index) = val;		
			index++;
		}
	}
	//�±�Ե�ݶ�
	for(i=lowYEnd-1;i>=lowYStart;i--)
	{
		index = i*imgWidth+XStart;
		for(j=XStart;j<XEnd;j++)
		{
			sum=0;			
			p_srcImg1 = (unsigned char *)(srcImg+index-imgWidth-maskLen);
			p_srcImg2 = (unsigned char *)(srcImg+index+imgWidth-maskLen);
			for( n=0;n<MASK_LEN;n++)
			{
				sum+= *(p_srcImg1++)- *(p_srcImg2++);
			}

			sum = sum<0?0:sum;
			sum = sum>255?255:sum;			
			val = (unsigned char)(sum);
			*(gradImg+index) = val;		
			index++;
		}
	}	

#endif
}


void roiLocation(const unsigned char *srcImg,unsigned char *dstImg,int *roiWidth,int *roiHeight, unsigned char *errorCode)
{
	//��ʼ��ͼ��ߴ�Ϊ�ɼ���ԭʼͼ��ߴ�
	int imgWidth = ORI_IMG_COLS;
	int imgHeight = ORI_IMG_ROWS;		
	unsigned char * resizeImg = c_buff_small1;

	unsigned char * gradImg=c_buff_big2;
	unsigned char *rotateImg1 = c_buff_big3;
	unsigned char *rotateImg2;	
	int uperRow=0, lowerRow=0;
	int leftCol=0, rightCol=0;	
	float angle = 0.0;//ƽ��ת��
	int fingeWidth = 0;
	Line midLine;	
	int uperPoints[MAX_SELECT_POINT_NUM] = {0}; 
	int lowerPoints[MAX_SELECT_POINT_NUM] = {0};


	*errorCode =0;
	*roiWidth = 0;
	*roiHeight = 0;

	
	if(srcImg==NULL||dstImg==NULL)
	{
		*errorCode = IMG_NULL_ERROR;	
		return ;
	}	
//ԭʼͼ����С
	imageResize((unsigned char *)srcImg, resizeImg, ORI_IMG_COLS,ORI_IMG_ROWS,ORI_IMG_COLS/2, ORI_IMG_ROWS/2);
	imgWidth = ORI_IMG_COLS/2;
	imgHeight = ORI_IMG_ROWS/2;		
	FingerEdgeGrad(resizeImg,gradImg,imgWidth, imgHeight);//�����ݶ�ͼ ͻ��ͼ���Ե
	DetectEdgePoints(gradImg,uperPoints,lowerPoints, imgWidth, imgHeight);//���ѡȡ��Ե��
	int ret = findMiddleLine(uperPoints,lowerPoints,imgWidth, imgHeight,&midLine);		//�ҵ������� Ϊ��ת��׼��
	/*if(ret!=0)
	{
		*errorCode = IMG_EDGE_DETECT_ERROR;
		return;
	}*/	
	if(0!=ret)
	{
		ret = RelocateEdge(resizeImg,uperPoints,lowerPoints,imgWidth, imgHeight);//��Ե�㲻����ʧ��ʱ���¶�λ
		if(0!=ret)
		{
			*errorCode = IMG_EDGE_DETECT_ERROR;
			return;
		}
		ret = findMiddleLine(uperPoints,lowerPoints,imgWidth, imgHeight,&midLine);
		if(0!=ret)
		{
			*errorCode = IMG_EDGE_DETECT_ERROR;
			return;
		}
	}
	//ƫת��
	angle = atan(midLine.k)*180/PI;	//������ ȡ�Ƕ�
	//��ת�Ƕȹ���
	if(angle> MAX_ANGEL||angle <(-1.0)*MAX_ANGEL)
	{
		*errorCode = ROI_LARGER_ANGEL_ERROR;
		return;
	}

	//����1.
	//imageRotate(gradImg,rotateImg1,imgWidth, imgHeight,angle);
//	DetectFingerEdge1(rotateImg1,imgWidth,&uperRow,&lowerRow);

	//����2��ʹ�ñ�Ե����ת����ͼ����ת��uperPoints��Ե����ת�����͵�y������uperRow��lowerPoints��Ե����ת����ߵĵ��y������lowerRow��
	DetectFingerEdge(uperPoints,lowerPoints,imgWidth, imgHeight,angle, &uperRow,&lowerRow);//��Ե����ת ȡ����� ��͵�����

	rotateImg2 = c_buff_big3;
	imageRotate(resizeImg,rotateImg2,imgWidth, imgHeight,angle);	//ͼ����ת

	leftCol = ROI_LEFT_COLUM_FIX;
	rightCol = ROI_RIGHT_COLUM_FIX;
	getBlock(rotateImg2,dstImg,imgWidth,leftCol,uperRow,rightCol-leftCol,lowerRow-uperRow);//��ȡ

	*roiWidth = rightCol-leftCol;
	*roiHeight = lowerRow-uperRow;//ͼ����������ʱ ���µ��� ������   lower ��ʵ��ͼ����ʵ������ ����    uper����
}

void GetROI(unsigned char *srcImg,unsigned char *dstImg, int *upLine,int *lowLine ,unsigned char *errorCode)
{

	//��ʼ��ͼ��ߴ�Ϊ�ɼ���ԭʼͼ��ߴ�
	int imgWidth = ORI_IMG_COLS;
	int imgHeight = ORI_IMG_ROWS;		
	unsigned char * resizeImg = c_buff_small1;

	unsigned char * gradImg=c_buff_big2;
	unsigned char *rotateImg1 = c_buff_big3;
	unsigned char *rotateImg2;	
	int uperRow=0, lowerRow=0;
	int leftCol=0, rightCol=0;	
	float angle = 0.0;//ƽ��ת��
	int fingeWidth = 0;
	Line midLine;	
	int uperPoints[MAX_SELECT_POINT_NUM] = {0}; 
	int lowerPoints[MAX_SELECT_POINT_NUM] = {0};


	*errorCode =0;
	*upLine = 0;
	*lowLine = 0;

	
	if(srcImg==NULL||dstImg==NULL)
	{
		*errorCode = IMG_NULL_ERROR;	
		return ;
	}	
//ԭʼͼ����Сһ��
	imageResize((unsigned char *)srcImg, resizeImg, ORI_IMG_COLS,ORI_IMG_ROWS,ORI_IMG_COLS/2, ORI_IMG_ROWS/2);
	imgWidth = ORI_IMG_COLS/2;
	imgHeight = ORI_IMG_ROWS/2;		
	FingerEdgeGrad(resizeImg,gradImg,imgWidth, imgHeight);
	DetectEdgePoints(gradImg,uperPoints,lowerPoints, imgWidth, imgHeight);
	int ret = findMiddleLine(uperPoints,lowerPoints,imgWidth, imgHeight,&midLine);		
	if(ret!=0)
	{
		*errorCode = IMG_EDGE_DETECT_ERROR;
		return;
	}
	//ƫת��
	angle = atan(midLine.k)*180/PI;	
	//��ת�Ƕȹ���
	if(angle> MAX_ANGEL||angle <(-1.0)*MAX_ANGEL)
	{
		*errorCode = ROI_LARGER_ANGEL_ERROR;
		return;
	}

	//����1.
	//imageRotate(gradImg,rotateImg1,imgWidth, imgHeight,angle);
//	DetectFingerEdge1(rotateImg1,imgWidth,&uperRow,&lowerRow);

	//����2��ʹ�ñ�Ե����ת����ͼ����ת��uperPoints��Ե����ת�����͵�y������uperRow��lowerPoints��Ե����ת����ߵĵ��y������lowerRow��
	DetectFingerEdge(uperPoints,lowerPoints,imgWidth, imgHeight,angle, &uperRow,&lowerRow);

	rotateImg2 = c_buff_big3;
	imageRotate(resizeImg,dstImg,imgWidth, imgHeight,angle);	

	*upLine = uperRow;
	*lowLine = lowerRow;

	/*leftCol = ROI_LEFT_COLUM_FIX;
	rightCol = ROI_RIGHT_COLUM_FIX;
	getBlock(rotateImg2,dstImg,imgWidth,leftCol,uperRow,rightCol-leftCol,lowerRow-uperRow);

	*roiWidth = rightCol-leftCol;
	*roiHeight = lowerRow-uperRow;*/
}