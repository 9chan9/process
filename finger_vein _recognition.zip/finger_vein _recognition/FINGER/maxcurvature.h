#ifndef MAX_CURVATURE_H
#define MAX_CURVATURE_H

//#include <opencv2/imgproc/imgproc.hpp>
#include<opencv2/opencv.hpp> 
//void MaxCurvature(cv::InputArray src, cv::OutputArray dst, cv::InputArray mask, double sigma);
//void MaxCurvature(cv::Mat  _src, cv::Mat _dst, cv::Mat  _mask, double sigma);
//Mat MaxCurvature(cv::Mat  _src, cv::Mat _dst, cv::Mat  _mask, double sigma);
void MaxCurvature(cv::Mat & _src, cv::Mat & _dst, cv::Mat & _mask, double sigma);
#endif // MAX_CURVATURE_H
