#ifndef __CPTSIMILARITY_H_
#define __CPTSIMILARITY_H_

#include<opencv2/opencv.hpp> 
double cptsimilarity(cv::Mat src_one, cv::Mat src_two);
#endif