/*
Author: Xu Jinhui
School: Wuyi University
Grade: sophomore
Time: 2018.7.28 - 2018.8.3
notes:If you want to use this project code in the blog or project, please indicate the author's information.

*/



#include "maxcurvature.h"
//#include <opencv2/highgui/highgui.hpp>
#include <iostream>
#include<opencv2/opencv.hpp>
#include "cptsimilarity.h"
#include "fileOp.h"
#include "GRGFingerVenaIDAlgorithm.h"
#include "ROILocation.h"

int main()
{
	cv::Mat roiImg;
	cv::Mat roiImg_gray;
	cv::Mat mask;
	cv::Mat maxCurvatureImg;
	cv::Mat image;
	int sum = 0;
	int roiWidth = 0, roiHeight = 0;
	unsigned char status = 0;

	std::string filePath = "all_img\\";
	std::vector<std::string> files;
	std::string format = "";				 //�����ļ��ĸ�ʽ
	getAllFiles(filePath, files, format);
	int size = files.size();
	//���Ѿ�Ԥ������ϣ���ο���ע��
	for (int i = 0; i<size; i++)
	{
		std::cout << files[i] << std::endl;
		image = cv::imread(files[i], 0);
		roiWidth = 0; roiHeight = 0;
		status = 0;
		unsigned char *dstBuff = new unsigned char[ORI_IMG_COLS*ORI_IMG_ROWS];
		roiLocation(image.data, dstBuff, &roiWidth, &roiHeight, &status);//�㷨
		if (status != 0)
		{
			printf("\nroiʧ�ܣ�");
			sum++;
		}
		else
		{
			roiImg = cv::Mat(roiHeight, roiWidth, CV_8U, dstBuff);
			imwrite(replace_all(string(files[i]), "all", "roi"), roiImg);

			//roiImg_gray.create(roiImg.size(), CV_8U);
			//cvtColor(roiImg, roiImg_gray, CV_RGB2GRAY);
			roiImg_gray = cv::imread(replace_all(string(files[i]), "all", "roi"), 0);
			mask = cv::Mat::ones(roiImg_gray.size(), CV_8U);
			MaxCurvature(roiImg_gray, maxCurvatureImg, mask, 8);//�㷨
			imwrite(replace_all(string(files[i]), "all", "maxCurvature"), maxCurvatureImg);

		}
		delete dstBuff;
	}
	
	//ƥ��ϵ��ԽС Խ����  ����ѡȡ�ļ�����ͬһ���˵���ָ ���Բ�ֵ���� ����Ȥ�����г��Բ�ͬͼ��
	cv::Mat finger = cv::imread("maxCurvature_img\\003.bmp", CV_LOAD_IMAGE_GRAYSCALE);
	cv::Mat matching;
	double S;

	std::string matchingPath = "maxCurvature_img\\";
	std::vector<std::string> matchingFiles;
	std::string matchingFormat = "";				 //�����ļ��ĸ�ʽ
	getAllFiles(matchingPath, matchingFiles, matchingFormat);
	int matchingSize = matchingFiles.size();
	for (int i = 0; i < matchingSize; i++)
	{
		matching = cv::imread(matchingFiles[i], CV_LOAD_IMAGE_GRAYSCALE);
		S = cptsimilarity(finger, matching);
		std::cout << "maxCurvature_img\\003.bmp ��ͼƬ " << replace_all(string(files[i]), "all", "maxCurvature") << "��ƥ��ϵ��Ϊ " << S << endl;
	}

	
	system("pause");
	return 0;
}
