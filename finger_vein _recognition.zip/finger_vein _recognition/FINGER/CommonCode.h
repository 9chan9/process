
#ifndef COMMON_CODE_H
#define COMMON_CODE_H


/*
GRG Finger Vein liberay version :V1.0000015,
*/
#if defined (WIN32) || defined (LINUX)
#define MB_LEN_MAX    5             /* max. # bytes in multibyte char */
#define SHRT_MIN    (-32768)        /* minimum (signed) short value */
#define SHRT_MAX      32767         /* maximum (signed) short value */
#define USHRT_MAX     0xffff        /* maximum unsigned short value */
#define INT_MIN     (-2147483647 - 1) /* minimum (signed) int value */
#define INT_MAX       2147483647    /* maximum (signed) int value */
#define UINT_MAX      0xffffffff    /* maximum unsigned int value */
#define LONG_MIN    (-2147483647L - 1) /* minimum (signed) long value */
#define LONG_MAX      2147483647L   /* maximum (signed) long value */
#define ULONG_MAX     0xffffffffUL  /* maximum unsigned long value */
#define LLONG_MAX     9223372036854775807i64       /* maximum signed long long int value */
#define LLONG_MIN   (-9223372036854775807i64 - 1)  /* minimum signed long long int value */
#define ULLONG_MAX    0xffffffffffffffffui64       /* maximum unsigned long long int value */
#endif
#define PI 3.1415926535897932384626433832795//3.14159

//����ֱ�ߵĽṹ��
typedef struct Line
{
	float b;
	float k;
	int flag;
}Line;

typedef struct Point
{
	int x;
	int y;
}Point;
//void imgShow(unsigned char *srcImg,int imgWidth,int imgHeight,char *dir);
void pixelCount(const unsigned char * srcImg, int width, int height, int*fpixelNum, int *bpixelNum);
void charToBit(const unsigned char *inTemp, unsigned char *outTemp,int imgSize);
void bitToChar(const unsigned char *inputData, unsigned char *outputData,int imgSize);
void imgBinary(unsigned char *srcImg,int imgW,int imgH,int threshold);
//�ռ��ʼ��
//ʹ��ָ��ֵ��ʼ��
void initBuff_UCHAR(unsigned char *orgBuff,int width, int height,unsigned char val);
void initBuff_INT(int *orgBuff,int width, int height,int val);
void initBuff_FLOAT(float *orgBuff,int width, int height,float val);
//ʹ��ָ���Ŀռ�����ݳ�ʼ��
void dataCopy(const unsigned char * inputData,unsigned char *outputData,int width, int height);

//ͼ����ת
void imageRotate(const  unsigned char *orgImg,unsigned char *rotateImg,int width,int height,float angle);
//ͼ������
void imageResize0(unsigned char *srcImg0, unsigned char *dstImg, int srcW, int srcH, int srcStep, int dstW, int dstH);
void imageResize(unsigned char *srcImg,unsigned char *dstImg,int srcWidth,int srcHeight,int dstWidth,int dstHeight);
void imageShift(unsigned char * srcImg,unsigned char * dstImg,int width, int height, int xStep,int yStep);
//��ȡ�ƶ�����ʹ�С������
void getBlock(const unsigned char *orgImg,unsigned char *dstImg,int imgWidth,int startX,int startY,int buffWidth,int buffHeight);
//��ͼ�����ܼӱ߽�
void getBorderImg_UCHAR(unsigned char * srcImg, unsigned char * borderImg, int srcW,int srcH, int borderW);
void getBorderImg_FLOAT(float * srcImg, float * borderImg, int srcW,int srcH, int borderW);
void getBorderImg_UCHAR2FLOAT(unsigned char * srcImg, float * borderImg, int srcW,int srcH, int borderW);

//��̬ѧ���㣺1�������㣻2��������
void morphologyEx(unsigned char *image,int width,int height,int type);
//����
void diate(unsigned char *image,int width,int height,int r );
//��ʴ
void erosion(unsigned char *image,int width,int height,int r );

void matSubtract(unsigned char *srcImg1,unsigned char *srcImg2,int *dstImg,int width,int height);
void matMultiply(float *srcImg1,float *srcImg2,float *dstImg,int width,int height);
void matMultAdd(float *srcImg1,float k,float *srcImg2,float *dstImg,int width,int height);
void matDivide(float *srcImg,float k,float *dstImg,int width,int height);
void matNot(float *image,int width, int height);
void matExp(float *image,int width, int height);
void meanFilter(unsigned char * srcImg,unsigned char * dstImg,int imgW,int imgH,int blockSize);
void oustThreshold(int *srcImg,int imgW,int imgH,int *Thresholdbest);
//��ȡ���ֵ��Сֵ
void getMaxMin_INT(int *srcImg,int imgW,int imgH,int *pMax,int *pMin);
void getMaxMin_UCHAR(unsigned char * srcImg,int imgW, int imgH,unsigned char * pMax,unsigned char * pMin);
float variance(unsigned char *buff,int length);
float variance_INT(int *buff,int length);
int getCycleTransform(unsigned char tmpArray[],int len);

//����ת��
void vDataTransf(const unsigned char *srcImg, unsigned char *dstImg);

//����
//void vEncryptTempInit(unsigned char *DeEncriptKey);
void imgDecrypt(unsigned char *imageData,unsigned char *DeEncriptKey,int length);
void encryptKeyInit(unsigned char *DeEncriptKey,float x0, int u0,int length);
void imgDecrypt(unsigned char *inputData,unsigned char *outputData,unsigned char *DeEncriptKey,int length);
void dataEnDecrypt(unsigned char *srcData,unsigned char *dstData,int imgSize);
//����������Base64����
void  base64EncodeUCHAR( const unsigned char * inputData, char * outputData, int inputLen,int *outPutLen );
int base64DecodeUCHAR( const unsigned char * inutData, unsigned char * outputData, int inputLen,int *outPutLen );
int isErrorModel(unsigned char *model, int modelLen);
#endif
