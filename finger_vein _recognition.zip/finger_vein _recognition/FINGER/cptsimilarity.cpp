#include <iostream>
#include "cptsimilarity.h"
//#include <opencv/opencv.hpp>
#include <opencv2/core/types_c.h>
#include <opencv2/core/operations.hpp>
#include <opencv2/highgui/highgui.hpp>
#include<opencv2/opencv.hpp> 

#define POSX 4
#define POSY 2
#define WINDOWSIZES 51
#define N 26
#define RESIZEHEIGHT 180
#define RESIZEWIDTH 100

double getPicSum(cv::Mat src)
{
	int width, height,sumPic = 0;
	width = src.cols;
	height = src.rows;

	for (int i = 0; i < height; i++)
	{
		for (int j = 0; j < width ; j++)
		{
			sumPic += src.at<uchar>(i, j);
		}
	}
	return sumPic;
}
void picSubtraction(cv::Mat src, cv::Mat dst, double num)
{
	cv::Mat csrc = src.clone();
	dst = src.clone();
	int width, height;
	width = csrc.cols;
	height = csrc.rows;

	for (int i = 0; i < height ; i++)
	{
		for (int j = 0; j < width ; j++)
		{
			dst.at<uchar>(i, j) = csrc.at<uchar>(i, j) - num;
		}
	}

}

double getAverage(cv::Mat src,int n)
{
	
	int n2;
	double sumPic = 0;

	n2 = 2 * n + 1;
	sumPic = getPicSum(src);

	return sumPic / (n2 * n2);
}

double getStandardDeviation(cv::Mat src, int n)
{
	cv::Mat _src = src.clone();
	double sum = 0;
	int width, height;
	double avg = getAverage(_src, n);
	width = _src.cols;
	height = _src.rows;

	for (int i = 0; i < height; i++)
	{
		for (int j = 0; j < width ; j++)
		{
			_src.at<uchar>(i, j) = pow((_src.at<uchar>(i, j) - avg),2);
			sum += _src.at<uchar>(i, j);
		}
	}

	return (pow(sum, 0.5)) / (2 * n + 1);
}

double calculationCorrelationCoefficient(cv::Mat src_one, cv::Mat src_two, int n)
{

	cv::Mat csrc_one = src_one.clone();
	cv::Mat csrc_two = src_two.clone();
	double stdDeviation_one, stdDeviation_two;
	double avg_one, avg_two;
	double sum;


	stdDeviation_one = getStandardDeviation(csrc_one,n);
	stdDeviation_two = getStandardDeviation(csrc_two, n);

	avg_one = getAverage(csrc_one, n);
	avg_two = getAverage(csrc_two, n);

	cv::Mat nImg1 = csrc_one.clone();
	cv::Mat nImg2 = csrc_one.clone();
	cv::Mat nImg3 = csrc_one.clone();

	picSubtraction(csrc_one, nImg1, avg_one);
	picSubtraction(csrc_two, nImg2, avg_two);

	multiply(nImg1, nImg2, nImg3);
	sum = getPicSum(nImg3);

	return sum / (pow((2 * n - 1), 2) * stdDeviation_one * stdDeviation_two);  //sum(sum(a.*b))/sqrt(sum(sum(a.*a))*sum(sum(b.*b))) correlation coefficient
}

void getPositions(int x[], int y[], int windowSize)
{
	int idx = 0,a = 0,i = 0,j = 0;
	int idxTem;
	while (idx < 179)
	{
		a = (idx == 0) ? 0 : 8;
		idx = (idx - a != 129) ? (idx - a) : (idx - a - 1);
		x[i] = idx;
		i++;

		idxTem = idx + windowSize;
		idx = idxTem;

	}
	idx = 0;

	while (idx < 99)
	{
		a = (idx == 0) ? 0 : 3;
		idx -= a;
		y[j] = idx;
		j++;
		idxTem = idx + windowSize;
		idx = idxTem;
	}

}

double cptsimilarity(cv::Mat src_one, cv::Mat src_two)
{

	
	double sums = 0;
	cv::Mat csrc_one = src_one.clone();
	cv::Mat csrc_two = src_two.clone();
	cv::Size dsize = cv::Size(RESIZEWIDTH, RESIZEHEIGHT);
	//cv::Size dsize = cv::Size(240, 320);
	cv::resize(src_one, csrc_one, dsize, CV_INTER_LINEAR);
	cv::resize(src_two, csrc_two, dsize, CV_INTER_LINEAR);
	int x[POSX];
	int y[POSY];
	getPositions(x, y, WINDOWSIZES);

	for (int i = 0; i < POSX ; i++)
	{
		for (int j = 0; j < POSY ; j++)
		{
			//cv::Mat tem = src_one(Range(x[i], x[i] + WINDOWSIZES), Range(y[j], y[j] + WINDOWSIZES))
			//cv::Mat tem1(csrc_one, cv::Rect(x[i], y[j], WINDOWSIZES, WINDOWSIZES));
			//cv::Mat tem2(csrc_two, cv::Rect(x[i], y[j], WINDOWSIZES, WINDOWSIZES));
			cv::Mat tem1(csrc_one, cv::Range(x[i], x[i] + WINDOWSIZES), cv::Range(y[j],y[j] + WINDOWSIZES));
			cv::Mat tem2(csrc_two, cv::Range(x[i], x[i] + WINDOWSIZES), cv::Range(y[j], y[j] + WINDOWSIZES));
			sums += calculationCorrelationCoefficient(tem1, tem2, N);
		}
	}
	return sums / 8.0;																		//Mean correlation coefficient
}