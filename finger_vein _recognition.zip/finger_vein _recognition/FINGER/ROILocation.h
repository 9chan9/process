#ifndef ROI_LOCATION_H
#define ROI_LOCATION_H
#include "GRGFingerVenaIDAlgorithm.h"

void roiLocation(const unsigned char *srcImg, unsigned char *dstImg, int *roiWidth, int *roiHeight, unsigned char *errorCode);
void GetROI(unsigned char * inputImg, unsigned char *outputImg, int *upLine, int *lowLine, unsigned char *errorCode);
#endif